
# IAM Ticket Summarizer Agent

This repository contains the **system prompt and docs** for a read‑only agent that summarizes IAM‑related tickets from a weekly Excel export (SharePoint/OneDrive).

## Contents
- `SYSTEM_PROMPT.md` – Final, production system prompt
- `EXAMPLES.md` – Concrete examples for alignment
- `SECURITY.md` – Token and secret handling, escalation notes

## How to Use
- Paste `SYSTEM_PROMPT.md` into your LLM **System** message.
- Provide each ticket row as a JSON (**User** message) with fields like `RefID`, `Subject`, `Description`, `Country`.
- The agent replies **per ticket** in the strict output format.

> This repo intentionally contains **no credentials** and no live automation. Automations (e.g., Power Automate/Logic Apps/Task Scheduler) should reference this prompt and keep the execution read‑only.
