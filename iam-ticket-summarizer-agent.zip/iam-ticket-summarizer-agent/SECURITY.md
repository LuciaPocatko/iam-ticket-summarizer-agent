
# SECURITY

- **Do not commit tokens, secrets, or credentials** to this repository.
- If a token was exposed, **revoke it immediately** and create a new PAT with the **minimum required scopes**.
- This agent is **read-only** by design. Do not add actions that modify tickets/systems.
- Add a separate path for **SECURITY REVIEW REQUIRED** output (e.g., triage inbox) if productizing.
