
## Example A — Austria, Offboarding (Security trigger)
**Input:**
RefID: `INC-AT-2041` | Subject: `Leaver device decommission` | Description: `Leaver reported a stolen device LAP-AT-777. Please decommission and disable access.` | Country: `Austria`

**Output:**
```
**Ticket:** [Ref ID: INC-AT-2041]
**Category:** offboarding devices
**Reasoning:** "stolen device", "decommission", and "disable" indicate offboarding | Austria – Priority #1 | SECURITY REVIEW REQUIRED
**List of devices:** LAP-AT-777
```

## Example B — Austria, Onboarding (Subject override)
**Input:**
RefID: `SR-AT-5532` | Subject: `Onboarding – New Employee` | Description: `User will receive laptop next week.` | Country: `Austria`

**Output:**
```
**Ticket:** [Ref ID: SR-AT-5532]
**Category:** onboarding
**Reasoning:** Subject indicates onboarding | Austria – Priority #1
**List of devices:** laptop
```

## Example C — Non‑English
**Input:**
RefID: `REQ-DE-9910` | Subject: `Konto und Gerät löschen` | Description: `Bitte löschen Sie das Konto und entfernen Sie das Gerät LAP-DE-020.` | Country: `Germany`

**Output:**
```
**Ticket:** [Ref ID: REQ-DE-9910]
**Category:** unsupported
**Reasoning:** Ticket language not supported (non-English)
**List of devices:** Not specified
```
