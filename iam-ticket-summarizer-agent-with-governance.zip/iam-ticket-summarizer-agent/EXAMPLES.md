
## Example – Austria, Offboarding (Security)
Input → RefID: `INC-AT-2041`, Subject: `Leaver device decommission`, Country: `Austria`, Description: `stolen device LAP-AT-777; please decommission and disable access.`

Output →
**Ticket:** [Ref ID: INC-AT-2041]
**Category:** offboarding devices
**Reasoning:** "stolen device", "decommission", "disable" | Austria – Priority #1 | SECURITY REVIEW REQUIRED
**List of devices:** LAP-AT-777
