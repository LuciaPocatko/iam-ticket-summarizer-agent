
# Ownership & RACI

- **Agent Owner (Process):** IAM Operations Lead
- **Data Owner:** IAM Platform/Customer Data Owner
- **Model/Logic Owner:** IAM Engineering (Agent Maintainer)
- **Incident Response:** Security Operations (security flags), IAM Ops (run failures)
- **Kill Switch:** IAM Ops Lead (primary) / SecOps Duty Manager (backup)
