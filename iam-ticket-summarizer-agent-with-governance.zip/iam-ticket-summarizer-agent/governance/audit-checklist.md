
# Audit Checklist

- Evidence log present with run metadata & counters
- Output blocks match strict format (no extra fields)
- Deterministic re-run possible with same input/policy tag
- Policy versions & prompt tag recorded
- Stop conditions honored; failure report emitted when triggered
- Ownership & kill switch documented
