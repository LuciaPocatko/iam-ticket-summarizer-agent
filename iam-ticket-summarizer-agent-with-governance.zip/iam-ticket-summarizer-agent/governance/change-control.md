
# Change & Evolution

- **Changeable:** prompts/policies, device patterns, integrations, output schema.
- **Approval:** IAM Ops approves; SecOps approves security terms.
- **Testing:** unit tests on fixed dataset; regression diff vs last release; 1-week UAT.
- **Rollback:** tag releases; revert to last good tag if precision/recall or format regresses.
- **Record:** approver, date/time, change summary, PR link.
