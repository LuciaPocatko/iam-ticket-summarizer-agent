
# IAM Ticket Summarizer Agent

A read‑only agent that summarizes IAM tickets from a weekly Excel export. This package includes the **agent prompt** and **governance policies** in machine‑consumable files.

## Quick Start
1) Use `SYSTEM_PROMPT.md` as the **System** message in your agent runner.
2) Load policies from `governance/*.yaml` to enforce behavior, stop conditions, and device extraction filters.
3) For audits, emit a run log matching `governance/logging-schema.json`.

## Files
- `SYSTEM_PROMPT.md` – Final, production system prompt (+ governance addendum)
- `governance/governance-policy.yaml` – Operating boundaries, classification precedence, output format
- `governance/device-extraction.yaml` – Device/hostname extraction patterns and filters
- `governance/keyword-policies.yaml` – Onboarding/offboarding/security keywords
- `governance/logging-schema.json` – Evidence/log format for audits
- `governance/change-control.md` – Approval, testing, and rollback process
- `governance/ownership-raci.md` – Owners, responders, kill switch
- `governance/audit-checklist.md` – Steps to validate compliance per run
- `governance/GOVERNANCE_OVERVIEW.pdf` – Two‑page governance overview (optional)
